## v1.0.0

- Installs/Unistall epel_release
- CI enabled

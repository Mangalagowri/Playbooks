# net2grid.services

Starts up system services required for the NET2GRID base image

# Requirements

None

# Role Variables

None

# Dependencies

None

# Example Playbook

    - hosts: all
      roles:
        - net2grid.services

# License

MIT


# Author Information

Remco Brink <remco@net2grid.com>

